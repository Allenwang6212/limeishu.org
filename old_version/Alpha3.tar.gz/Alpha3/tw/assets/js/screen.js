while(1){ 
    var w = window.innerWidth;

    if(w<=980){
        block2.style.width = 80%;
    }

    else{
        block2.style.width = 33%;
    }
}