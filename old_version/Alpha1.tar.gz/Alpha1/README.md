李梅樹紀念館網站(Alpha)
Li Mei-shu website Alpha v1.0 by ZLCSC

http://github.com/ZLCSC-club/ | @ZLCSC-club

    Credits:

	   Main page:
        
            Aries Cs (github.com/Aries0d0f)

	   Icons:
		  Font Awesome (fortawesome.github.com/Font-Awesome)

	   Other:
		  jQuery (jquery.com)
		  html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		  CSS3 Pie (css3pie.com)
		  Respond.js (j.mp/respondjs)
		  Skel (skel.io)


    =========Li Mei-shu websit Alpha v1.0 - Developer notice==========

    Header >> 
        Interactivity Tage
            Tage Menu >>
                1.Home Page >> {Next button( Slide down )}
                    Laugrage Chooser 
                    Limeishu’s Introduction ( limt >> button >> know more // relink to Introduction/Limeishu’s Introduction  )
                    About Us ( limt >> button >> know more // relink to About Us  )
                    Active Introduction ( limt  >> button >> know more // relink to Introduction/Actives  )
                    Review
                    Content ( Limt >> google map iframe )
                2.About Us ( limt  >> button >> know more // relink to Introduction/Review  )
                    About Li Mei-shu Memorial Gallery ( resource :  http://www.limeishu.org/introduction.htm )
                    About Foundation ( resource : http://www.limeishu.org/foundation.htm )
                    Volunteers Team
                3.Introduction
                    I.Limeishu’s Introduction ( interactivity [Slide] )
                        Autobiology ( resource : http://www.limeishu.org/limei-shu_01.htm )
                        :Cover Style 
                        {  
                            [Paintings’ Time line] ( source : http://www.limeishu.org/works_01.asp ) & [Paintings’ Style] ( resource :  http://www.limeishu.org/limei-shu_03.htm )
                        }
                        Lifes Story about Limeishu ( resource : http://www.limeishu.org/limei-shu_02.htm style : css table )
                    II.Sanxia Bird Temple
                        History ( resource : http://www.limeishu.org/temple_01.htm )
                        :Cover Style
                        {
                            Time Line ( resource : http://www.limeishu.org/temple_02.htm )
                        }
                        Feature  ( resource :  http://www.limeishu.org/temple_04.htm )
                        Picture ( resource : http://www.limeishu.org/temple_03.htm )
                        Rules ( resource : http://www.limeishu.org/temple_05.htm )
                    III.Actives ( interactivity [Slide] )
                        Cover Style:
                        {
                            Sequence by Time
                        }
                    IV.Review
                        MeiShu-Mouth [ Time Line ( More ) ]
                        Other [ Time Line ( More ) ]
                        Review Videos
                4.Local Culture
                    Li Mei-shu Art Center
                    Local Business
                    Culture Attractions
                5.Open Soruce x Art History
                    Introduction Open Source ( Link : http://buzzorange.com/techorange/2014/12/19/what-is-open-source/ )
                    {
                    Website Source [ link to >> Github ]
                    }
	                How to Open Source
                    Open Source Contribution
                    Donate & Support Us
                6.Content
                    Cover Style
                    {
                        Google map ( iframe )
                        Content Informations
                        Traffic
                        Message Board
                    }

    Footer >>
        Copyright : Limeishu. All right reserved.
        Design :  ZLCSC ( link to )
        Unit Limeishu’s Website Project Processing Team ( LWPPT )
        CC-BY-NC-ND ( Website Page )
        Open Source ( Website Code )
        Icon >>
            Facebook page
            Mail
            Tel
            Fax
            Team

Support

    Old version website : http://www.limeishu.org/index.htm

    Deemo version website : http://www.limeishu.org/test/alpha/
